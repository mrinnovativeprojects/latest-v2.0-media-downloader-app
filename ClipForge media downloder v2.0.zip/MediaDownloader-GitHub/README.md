# ClipForge Media Downloader

ClipForge runs as a native Windows desktop application. The existing app UI is unchanged.

## First run
1. Extract the ZIP completely.
2. Right-click `RUN_AS_ADMIN.bat` and choose **Run as administrator**.
3. The installer copies ClipForge to `%LOCALAPPDATA%\ClipForge`, creates a private Python environment, installs dependencies, and creates Desktop and Start Menu shortcuts.
4. Use the single **ClipForge** Desktop shortcut to launch the app. It starts `pythonw.exe` directly, so no PowerShell or console window is shown.

Administrator permission is needed for the first installation/repair only. After installation, launch **ClipForge** from the Desktop shortcut like any other Windows application. Only one ClipForge instance is allowed at a time.

## Repair
If the installation is damaged, run `RUN_AS_ADMIN.bat` as Administrator again. It repairs installed files while preserving application data and logs.

## Logs
- `%LOCALAPPDATA%\ClipForge\logs\installer.log`
- `%LOCALAPPDATA%\ClipForge\logs\desktop.log`
- `%LOCALAPPDATA%\ClipForge\logs\app.log`

## Important
Use only media you are authorized to download. ClipForge does not bypass DRM, private content, paywalls, authentication, or access controls.

### Shortcut reliability
ClipForge resolves the actual Windows Desktop location (including redirected/OneDrive Desktop folders) and creates one Desktop shortcut. The app does not run shortcut-repair PowerShell on every normal launch.
